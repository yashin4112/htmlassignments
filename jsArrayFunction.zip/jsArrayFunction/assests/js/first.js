const array = [
    'C++', 
    'java',
    'c',
    'python',
    
];

const array2 = [
    'html',
    'js',
    'css'
];

const flatArray=[
    'C',
    'C++',
    [
        'java',
        'python',
        [
            [
                'html',
                'css',
                'js'
            ]
        ]
    ]
];

const numArray=[
    1,2,3,4,5
];

console.log('Concate Function',array.concat(array2));
console.log('Copy With Function',array.copyWithin(1,2,4));
const itr1 =  array.entries();
console.log('entries function',itr1.next().value);
console.log('entries function',itr1.next().value);
console.log('fill function',array.fill(2,4,3));
console.log('filter function',array.filter(item => item.length >2));
console.log('find function:',array.find((item)=> item.length>3));
console.log('find function',array.findIndex((item) => item.length>2));
console.log('flat function',flatArray.flat());
console.log('flat map function', numArray.flatMap(item => [item *2]));
console.log('For each function');
array.forEach((item) => console.log(item));
console.log('array from function',Array.from('python'));
console.log('includes function',array.includes('java'));
console.log('index of', array.indexOf('C++'));
console.log('is array function',Array.isArray([1,2,3]));
